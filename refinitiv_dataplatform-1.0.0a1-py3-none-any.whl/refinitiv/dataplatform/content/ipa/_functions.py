# coding: utf8


__all__ = ["get_bond_analytics",
           "get_option_analytics"]

from refinitiv.dataplatform.factory.content_factory import ContentFactory
from .financial_contracts import FinancialContracts


def get_instrument_analytics(universe,
                             fields=[],
                             pricing_params=None,
                             outputs=None,
                             on_response=None,
                             closure=None,
                             session=None):
    _fin = FinancialContracts(session=session, on_response=on_response)
    result = _fin.get_instrument_analytics(universe=universe,
                                           fields=fields,
                                           pricing_params=pricing_params,
                                           outputs=outputs,
                                           closure=closure)
    ContentFactory._last_result = result
    if result.is_success and result.data and result.data.df is not None:
        return result.data.df
    else:
        ContentFactory._last_error_status = result.status
        return None


def get_bond_analytics(universe,
                       fields=[],
                       pricing_params=None,
                       outputs=None,
                       on_response=None,
                       closure=None,
                       session=None):
    result = FinancialContracts.get_bond_analytics(universe=universe,
                                                   fields=fields,
                                                   pricing_params=pricing_params,
                                                   outputs=outputs,
                                                   on_response=on_response,
                                                   closure=closure,
                                                   session=session)
    ContentFactory._last_result = result
    if result.is_success and result.data and result.data.df is not None:
        return result.data.df
    else:
        ContentFactory._last_error_status = result.status
        return None


def get_option_analytics(universe,
                         fields=[],
                         pricing_params=None,
                         outputs=None,
                         on_response=None,
                         closure=None,
                         session=None):
    result = FinancialContracts.get_option_analytics(universe=universe,
                                                     fields=fields,
                                                     pricing_params=pricing_params,
                                                     outputs=outputs,
                                                     on_response=on_response,
                                                     closure=closure,
                                                     session=session)
    ContentFactory._last_result = result
    if result.is_success and result.data and result.data.df is not None:
        return result.data.df
    else:
        ContentFactory._last_error_status = result.status
        return None
