# coding: utf8

__all__ = ["AverageInfo"]

from refinitiv.dataplatform.content.ipa.instrument._definition import ObjectDefinition


class AverageInfo(ObjectDefinition):
    """
    """
    def __init__(self,
                 average_so_far=None,
                 average_type=None,
                 fixing=None):
        super().__init__()
        self.average_so_far = average_so_far
        self.average_type = average_type
        self.fixing = fixing

    @property
    def average_so_far(self):
        """
        The value of the AverageType
        :return: float
        """
        return self._get_parameter("averageSoFar")

    @average_so_far.setter
    def average_so_far(self, value):
        self._set_parameter("averageSoFar", value)

    @property
    def average_type(self):
        """
        The type of average used to compute.
        Possible values:
            ArithmeticRate
            ArithmeticStrike
            GeometricRate
            GeometricStrike
        :return: enum AverageType
        """
        from refinitiv.dataplatform.content.ipa.enum_types import AverageType
        return self._get_enum_parameter(AverageType, "averageType")

    @average_type.setter
    def average_type(self, value):
        from refinitiv.dataplatform.content.ipa.enum_types import AverageType
        self._set_enum_parameter(AverageType, "averageType", value)

    @property
    def fixing(self):
        """
        Barrier of the barrier option
        :return: double
        """
        from refinitiv.dataplatform.content.ipa.option.fx import FixingInfo
        return self._get_enum_parameter(FixingInfo, "fixing")

    @fixing.setter
    def fixing(self, value):
        from refinitiv.dataplatform.content.ipa.option.fx import FixingInfo
        self._set_enum_parameter(FixingInfo, "fixing", value)

    @property
    def rebate_amount(self):
        """
        Rebate of the barrier option
        :return: double
        """
        return self._get_parameter("rebateAmount")

    @rebate_amount.setter
    def rebate_amount(self, value):
        self._set_parameter("rebateAmount", value)

    @property
    def up_or_down(self):
        """
        Up/Down property of the barrier option.
        :return: string
        """
        return self._get_parameter("upOrDown")

    @up_or_down.setter
    def up_or_down(self, value):
        self._set_parameter("upOrDown", value)

    @property
    def window_start_date(self):
        """
        Up/Down property of the barrier option.
        :return: string
        """
        return self._get_parameter("windowStartDate")

    @window_start_date.setter
    def window_start_date(self, value):
        self._set_parameter("windowStartDate", value)

    @property
    def window_end_date(self):
        """
        Up/Down property of the barrier option.
        :return: string
        """
        return self._get_parameter("windowEndDate")

    @window_end_date.setter
    def window_end_date(self, value):
        self._set_parameter("windowEndDate", value)
