# coding: utf-8

import abc
import enum


class BarrierDefinition(abc.ABC):
    def __init__(self):
        pass


class BinaryDefinition(abc.ABC):
    def __init__(self):
        pass


class FixingInfo(abc.ABC):
    def __init__(self):
        pass


class BinaryType(enum.Enum):
    pass
