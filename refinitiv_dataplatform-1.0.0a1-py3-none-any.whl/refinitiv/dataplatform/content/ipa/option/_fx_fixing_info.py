# coding: utf8


__all__ = ["FxFixingInfo"]

from refinitiv.dataplatform.content.ipa.instrument._definition import ObjectDefinition
from refinitiv.dataplatform.content.ipa.enum_types import AmortizationFrequency
from ._abstracted_class import FixingInfo

class FxFixingInfo(ObjectDefinition, FixingInfo):
    """
    """
    def __init__(self,
                 fixing_frequency=None,
                 fixing_ric_source=None,
                 fixing_start_date=None,
                 include_holidays=None,
                 include_weekends=None):
        super().__init__()
        self.fixing_frequency = fixing_frequency
        self.fixing_ric_source = fixing_ric_source
        self.fixing_start_date = fixing_start_date
        self.include_holidays = include_holidays
        self.include_weekends = include_weekends

    @property
    def average_type(self):
        """
        :return: double
        """
        return self._get_parameter("averageType")

    @average_type.setter
    def average_type(self, value):
        self._set_parameter("RemainingNotional", value)

    @property
    def amortization_frequency(self):
        return self._get_parameter("AmortizationFrequency")

    @amortization_frequency.setter
    def amortization_frequency(self, value):
        self._set_enum_parameter(AmortizationFrequency, "AmortizationFrequency", value)

    @property
    def first_amortization_date(self):
        return self._get_enum_parameter(AmortizationFrequency, "firstAmortizationDate")

    @first_amortization_date.setter
    def first_amortization_date(self, value):
        self._set_parameter("firstAmortizationDate", value)

    @property
    def amount(self):
        return self._get_parameter("amount")

    @amount.setter
    def amount(self, value):
        self._set_parameter("amount", value)

    @property
    def amortization_type(self):
        return self._get_parameter("amortizationType")

    @amortization_type.setter
    def amortization_type(self, value):
        self._set_parameter("amortizationType", value)

    @property
    def start_date(self):
        """
        Start Date of an amortization section/window, or stepped rate
        :return: datetime
        """
        return self._get_parameter("startDate")

    @start_date.setter
    def start_date(self, value):
        self._set_parameter("startDate", value)

    @property
    def end_date(self):
        """
        End Date of an amortization section/window, or stepped rate
        :return: datetime
        """
        return self._get_parameter("endDate")

    @end_date.setter
    def end_date(self, value):
        self._set_parameter("endDate", value)
