# coding: utf8


__all__ = ["EtiFixingInfo"]

from refinitiv.dataplatform.content.ipa.instrument._definition import ObjectDefinition
from ._abstracted_class import FixingInfo


class EtiFixingInfo(ObjectDefinition, FixingInfo):
    """
    """
    def __init__(self,
                 average_type=None,
                 fixing_calendar=None,
                 fixing_end_date=None,
                 fixing_frequency=None,
                 fixing_start_date=None
                 ):
        super().__init__()
        self.average_type = average_type
        self.fixing_calendar = fixing_calendar
        self.fixing_end_date = fixing_end_date
        self.fixing_frequency = fixing_frequency
        self.fixing_start_date = fixing_start_date

    @property
    def average_type(self):
        """
        :return: double
        """
        from refinitiv.dataplatform.content.ipa.enum_types import AsianAverageType
        return self._get_enum_parameter(AsianAverageType, "averageType")

    @average_type.setter
    def average_type(self, value):
        from refinitiv.dataplatform.content.ipa.enum_types import AsianAverageType
        self._set_enum_parameter(AsianAverageType, "RemainingNotional", value)

    @property
    def fixing_calendar(self):
        """
        The calendar of the underlying's currency.
        :return: string
        """
        return self._get_parameter("fixingCalendar")

    @fixing_calendar.setter
    def fixing_calendar(self, value):
        self._set_parameter("fixingCalendar", value)

    @property
    def fixing_end_date(self):
        """
        The end date of the fixing period. Should be less or equal to the expiry.
        :return: string(datetime)
        """
        return self._get_parameter("fixingEndDate")

    @fixing_end_date.setter
    def fixing_end_date(self, value):
        self._set_parameter("fixingEndDate", value)

    @property
    def fixing_frequency(self):
        from refinitiv.dataplatform.content.ipa.enum_types import OptionFixingFrequency
        return self._get_enum_parameter(OptionFixingFrequency, "fixingFrequency")

    @fixing_frequency.setter
    def fixing_frequency(self, value):
        from refinitiv.dataplatform.content.ipa.enum_types import OptionFixingFrequency
        self._set_enum_parameter(OptionFixingFrequency, "fixingFrequency", value)

    @property
    def fixing_start_date(self):
        """
        The end date of the fixing period. Should be less or equal to the expiry.
        :return: string(datetime)
        """
        return self._get_parameter("fixingStartDate")

    @fixing_start_date.setter
    def fixing_start_date(self, value):
        self._set_parameter("fixingStartDate", value)
