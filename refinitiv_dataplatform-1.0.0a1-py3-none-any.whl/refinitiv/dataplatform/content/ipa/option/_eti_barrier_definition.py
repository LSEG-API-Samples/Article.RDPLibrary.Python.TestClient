# coding: utf8

__all__ = ["EtiBarrierDefinition", "EtiDoubleBarriersDefinition"]

from refinitiv.dataplatform.content.ipa.instrument._definition import ObjectDefinition
from ._abstracted_class import BarrierDefinition


class EtiBarrierDefinition(ObjectDefinition, BarrierDefinition):
    """
    """
    def __init__(self,
                 in_or_out=None,
                 level=None,
                 up_or_down=None
                 ):
        super().__init__()
        self.in_or_out = in_or_out
        self.level = level
        self.up_or_down = up_or_down

    @property
    def in_or_out(self):
        """
        :return: string
        """
        return self._get_parameter("inOrOut")

    @in_or_out.setter
    def in_or_out(self, value):
        self._set_parameter("inOrOut", value)

    @property
    def level(self):
        """
        :return: double
        """
        return self._get_parameter("level")

    @level.setter
    def level(self, value):
        self._set_parameter("level", value)

    @property
    def up_or_down(self):
        """
        :return: string
        """
        return self._get_parameter("upOrDown")

    @up_or_down.setter
    def up_or_down(self, value):
        self._set_parameter("upOrDown", value)


class EtiDoubleBarriersDefinition(ObjectDefinition):

    def __init__(self, double_barriers_definition):
        super().__init__()
        self.double_barriers_definition = double_barriers_definition

    @property
    def double_barriers_definition(self):
        """
        :return: list(BarrierDefinition)
        """
        return self._get_list_parameter(BarrierDefinition, "doubleBarriersDefinition")

    @double_barriers_definition.setter
    def double_barriers_definition(self, value):
        self._set_list_parameter(BarrierDefinition, "doubleBarriersDefinition", value)


