# coding: utf8

__all__ = ["OptionFixingFrequency"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class OptionFixingFrequency(Enum):
    DAILY = "Daily"
    WEEKLY = "Weekly"
    BIWEEKLY = "BiWeekly"
    MONTHLY = "Monthly"
    QUARTERLY = "Quarterly"
    SEMIANNUAL = "SemiAnnual"
    ANNUAL = "Annual"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(OptionFixingFrequency, OPTION_FIXING_FREQUENCY_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_OPTION_FIXING_FREQUENCY_VALUES_IN_LOWER_BY_OPTION_FIXING_FREQUENCY, some)


OPTION_FIXING_FREQUENCY_VALUES = (t.value for t in OptionFixingFrequency)
_OPTION_FIXING_FREQUENCY_VALUES_IN_LOWER_BY_OPTION_FIXING_FREQUENCY = {
    name.lower(): item for name, item in list(OptionFixingFrequency.__members__.items())}

