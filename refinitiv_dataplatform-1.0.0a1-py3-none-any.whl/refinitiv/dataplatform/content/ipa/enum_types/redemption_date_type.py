# coding: utf8

__all__ = ["RedemptionDateType"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class RedemptionDateType(Enum):
    """
    Redemption date type is used to compute the default redemption date:
        - REDEMPTION_AT_MATURITY_DATE : yield and price are computed at maturity date.
        - REDEMPTION_AT_CALL_DATE : yield and price are computed at call date (next call date by default).
        - REDEMPTION_AT_PUT_DATE : yield and price are computed at put date (next put date by default).
        - REDEMPTION_AT_WORST_DATE : yield and price are computed at the lowest yield date.
        - REDEMPTION_AT_BEST_DATE :
        - REDEMPTION_AT_SINK_DATE : yield and price are computed at sink date.
        - REDEMPTION_AT_PAR_DATE : yield and price are computed at next par.
        - REDEMPTION_AT_PREMIUM_DATE : yield and price are computed at next premium.
        - REDEMPTION_AT_PERPETUITY :
        - REDEMPTION_AT_CUSTOM_DATE :
        - REDEMPTION_AT_MAKE_WHOLE_CALL_DATE : yield and price are computed at Make Whole Call date.
        - REDEMPTION_AT_AVERAGE_LIFE : yield and price are computed at average life (case of sinkable bonds)
    """

    REDEMPTION_AT_MATURITY_DATE = "RedemptionAtMaturityDate"
    REDEMPTION_AT_CALL_DATE = "RedemptionAtCallDate"
    REDEMPTION_AT_PUT_DATE = "RedemptionAtPutDate"
    REDEMPTION_AT_WORST_DATE = "RedemptionAtWorstDate"
    REDEMPTION_AT_BEST_DATE = "RedemptionAtBestDate"
    REDEMPTION_AT_SINK_DATE = "RedemptionAtSinkDate"
    REDEMPTION_AT_PAR_DATE = "RedemptionAtParDate"
    REDEMPTION_AT_PREMIUM_DATE = "RedemptionAtPremiumDate"
    REDEMPTION_AT_PERPETUITY = "RedemptionAtPerpetuity"
    REDEMPTION_AT_CUSTOM_DATE = "RedemptionAtCustomDate"
    REDEMPTION_AT_MAKE_WHOLE_CALL_DATE = "RedemptionAtMakeWholeCallDate"
    REDEMPTION_AT_AVERAGE_LIFE = "RedemptionAtAverageLife"
    REDEMPTION_AT_PARTIAL_CALL_DATE = "RedemptionAtPartialCallDate"
    REDEMPTION_AT_PARTIAL_PUT_DATE = "RedemptionAtPartialPutDate"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(RedemptionDateType, _REDEMPTION_DATE_TYPE_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_REDEMPTION_DATE_TYPE_VALUES_IN_LOWER_BY_REDEMPTION_DATE_TYPE, some)


_REDEMPTION_DATE_TYPE_VALUES = (t.value for t in RedemptionDateType)
_REDEMPTION_DATE_TYPE_VALUES_IN_LOWER_BY_REDEMPTION_DATE_TYPE = {
    name.lower(): item for name, item in list(RedemptionDateType.__members__.items())}

