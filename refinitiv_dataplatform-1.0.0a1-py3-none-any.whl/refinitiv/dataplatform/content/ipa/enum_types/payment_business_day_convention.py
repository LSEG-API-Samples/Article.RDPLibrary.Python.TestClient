# coding: utf8

__all__ = ["PaymentBusinessDayConvention"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class PaymentBusinessDayConvention(Enum):
    """
    The method to adjust dates to a working day.
    The possible values are:
        - MODIFIED_FOLLOWING : adjusts dates according to the Modified Following convention - next business day unless
        is it goes into the next month, preceeding is used in that  case,
        - NEXT_BUSINESS_DAY : adjusts dates according to the Following convention - Next Business Day,
        - PREVIOUS_BUSINESS_DAY : adjusts dates  according to the Preceeding convention - Previous Business Day,
        - NO_MOVING : does not adjust dates),
        - BBSW_MODIFIED_FOLLOWING : adjusts dates  according to the BBSW Modified Following convention).
    """

    MODIFIED_FOLLOWING = "ModifiedFollowing"
    NEXT_BUSINESS_DAY = "NextBusinessDay"
    PREVIOUS_BUSINESS_DAY = "PreviousBusinessDay"
    NO_MOVING = "NoMoving"
    BBSW_MODIFIED_FOLLOWING = "BbswModifiedFollowing"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(PaymentBusinessDayConvention, PAYMENT_BUSINESS_DAY_CONVENTION_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_PAYMENT_BUSINESS_DAY_CONVENTION_VALUES_IN_LOWER_BY_PAYMENT_BUSINESS_DAY_CONVENTION, some)


PAYMENT_BUSINESS_DAY_CONVENTION_VALUES = (t.value for t in PaymentBusinessDayConvention)
_PAYMENT_BUSINESS_DAY_CONVENTION_VALUES_IN_LOWER_BY_PAYMENT_BUSINESS_DAY_CONVENTION = {
    name.lower(): item for name, item in list(PaymentBusinessDayConvention.__members__.items())}

