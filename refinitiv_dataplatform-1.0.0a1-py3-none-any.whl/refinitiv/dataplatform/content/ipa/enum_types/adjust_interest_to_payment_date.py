# coding: utf8

__all__ = ["AdjustInterestToPaymentDate"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class AdjustInterestToPaymentDate(Enum):
    """
    A flag that indicates if the coupon dates are adjusted to the payment dates.
    """
    UNADJUSTED = "Unadjusted"
    ADJUSTED = "Adjusted"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(AdjustInterestToPaymentDate, ADJUST_INTEREST_TO_PAYMENT_DATE_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_ADJUST_INTEREST_TO_PAYMENT_DATE_VALUES_IN_LOWER_BY_ADJUST_INTEREST_TO_PAYMENT_DATE, some)


ADJUST_INTEREST_TO_PAYMENT_DATE_VALUES = (t.value for t in AdjustInterestToPaymentDate)
_ADJUST_INTEREST_TO_PAYMENT_DATE_VALUES_IN_LOWER_BY_ADJUST_INTEREST_TO_PAYMENT_DATE = {
    name.lower(): item for name, item in list(AdjustInterestToPaymentDate.__members__.items())}
