# coding: utf8

__all__ = ["PaymentRollConvention"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class PaymentRollConvention(Enum):
    """
        Enum for payment dates when they fall at the end of the month (28th of February, 30th, 31st).
        The possible values are:
            - LAST : For setting the calculated date to the last working day),
            - SAME : For setting the calculated date to the same day.
                In this latter case, the date may be moved according to the date moving convention if it's a none-working day),
            - LAST28 : For setting the calculated date to the last working day. 28FEB being always considered as the last working day),
            - SAME28 : For setting the calculated date to the same day .28FEB being always considered as the last working day).
    """

    LAST = "Last"
    SAME = "Same"
    LAST28 = "Last28"
    SAME28 = "Same28"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(PaymentRollConvention, PAYMENT_ROLL_CONVENTION_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_PAYMENT_ROLL_CONVENTION_VALUES_IN_LOWER_BY_PAYMENT_ROLL_CONVENTION, some)


PAYMENT_ROLL_CONVENTION_VALUES = (t.value for t in PaymentRollConvention)
_PAYMENT_ROLL_CONVENTION_VALUES_IN_LOWER_BY_PAYMENT_ROLL_CONVENTION = {
    name.lower(): item for name, item in list(PaymentRollConvention.__members__.items())}
