# coding: utf8

__all__ = ["StubRule"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class StubRule(Enum):
    """
    The rule that defines whether coupon roll dates are aligned on the  maturity or the issue date.
    The possible values are:
        - SHORT_FIRST_PRORATA : to create a short period between the start date and the first coupon date, and pay a
            smaller amount of interest for the short period.All coupon dates are calculated backward from the maturity date,
        - SHORT_FIRST_FULL : to create a short period between the start date and the first coupon date, and pay a regular
            coupon on the first coupon date. All coupon dates are calculated backward from the maturity date,
        - LONG_FIRST_FULL : to create a long period between the start date and the second coupon date, and pay a regular
            coupon on the second coupon date. All coupon dates are calculated backward from the maturity date,
        - SHORT_LAST_PRORATA : to create a short period between the last payment date and maturity, and pay a smaller
            amount of interest for the short period. All coupon dates are calculated forward from the start date.
    This property may also be used in conjunction with firstRegularPaymentDate and lastRegularPaymentDate; in that case
     the following values can be defined:
        - ISSUE : all dates are aligned on the issue date,
        - MATURITY : all dates are aligned on the maturity date.
    """

    ISSUE = "Issue"
    MATURITY = "Maturity"
    SHORT_FIRST_PRORATA = "ShortFirstProRata"
    SHORT_LAST_PRORATA = "ShortLastProRata"
    SHORT_FIRST_FULL = "ShortFirstFull"
    LONG_FIRST_FULL = "LongFirstFull"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(StubRule, STUBRULE_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_STUBRULE_VALUES_IN_LOWER_BY_STUBRULE, some)


STUBRULE_VALUES = (t.value for t in StubRule)
_STUBRULE_VALUES_IN_LOWER_BY_STUBRULE = {
    name.lower(): item for name, item in list(StubRule.__members__.items())}
