# coding: utf8

__all__ = ["VolatilityModel"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class VolatilityModel(Enum):
    """
    The quantitative model used to generate the volatility surface. This may depend on the asset class.
    For Fx Volatility Surface, we currently support the SVI model.
        - SVI
        - SABR
        - CubicSpline
        - TwinLognormal
    """
    SVI = "SVI"
    SABR = "SABR"
    CUBIC_SPLINE = "CubicSpline"
    TWIN_LOGNORMAL = "TwinLognormal"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(VolatilityModel, VOLATILITY_MODEL_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_VOLATILITY_MODEL_VALUES_IN_LOWER_BY_VOLATILITY_MODEL, some)


VOLATILITY_MODEL_VALUES = (t.value for t in VolatilityModel)
_VOLATILITY_MODEL_VALUES_IN_LOWER_BY_VOLATILITY_MODEL = {
    name.lower(): item for name, item in list(VolatilityModel.__members__.items())}
