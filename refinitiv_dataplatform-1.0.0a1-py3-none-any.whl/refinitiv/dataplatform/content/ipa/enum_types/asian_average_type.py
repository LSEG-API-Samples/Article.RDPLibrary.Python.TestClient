# coding: utf8

__all__ = ["AsianAverageType"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class AsianAverageType(Enum):
    DAILY = "ArithmeticRate"
    WEEKLY = "ArithmeticStrike"
    BIWEEKLY = "GeometricRate"
    MONTHLY = "GeometricStrike"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(AsianAverageType, _ASIAN_AVERAGE_TYPE_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_ASIAN_AVERAGE_TYPE_VALUES_IN_LOWER_BY_ASIAN_AVERAGE_TYPE_VALUES, some)


_ASIAN_AVERAGE_TYPE_VALUES = (t.value for t in AsianAverageType)
_ASIAN_AVERAGE_TYPE_VALUES_IN_LOWER_BY_ASIAN_AVERAGE_TYPE_VALUES = {
    name.lower(): item for name, item in list(AsianAverageType.__members__.items())}

