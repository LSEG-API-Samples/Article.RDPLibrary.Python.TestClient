# coding: utf8

__all__ = ["IndexCompoundingMethod"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class IndexCompoundingMethod(Enum):
    """
        A flag that defines how the coupon rate is calculated from the reset floating rates when the reset frequency
            is higher than the interest payment frequency (e.g. daily index reset with quarterly interest payment).
        The possible values are:
            - COUMPOUNDED : uses the compounded average rate from multiple fixings,
            - AVERAGE : uses the arithmetic average rate from multiple fixings,
            - CONSTANT : uses the last published rate among multiple fixings,
            - ADJUSTEDCOUMPOUNDED : uses Chinese 7-day repo fixing,
            - MEXICANCOUMPOUNDED : uses Mexican Bremse fixing.
    """

    COUMPOUNDED = "Compounded"
    ADJUSTEDCOUMPOUNDED = "AdjustedCompounded"
    MEXICANCOUMPOUNDED = "MexicanCompounded"
    AVERAGE = "Average"
    CONSTANT = "Constant"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(IndexCompoundingMethod, INDEX_COMPOUNDING_METHOD_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_INDEX_COMPOUNDING_METHOD_VALUES_IN_LOWER_BY_INDEX_COUMPOUNDING_METHOD_VALUES, some)


INDEX_COMPOUNDING_METHOD_VALUES = (t.value for t in IndexCompoundingMethod)
_INDEX_COMPOUNDING_METHOD_VALUES_IN_LOWER_BY_INDEX_COMPOUNDING_METHOD = {
    name.lower(): item for name, item in list(IndexCompoundingMethod.__members__.items())}

