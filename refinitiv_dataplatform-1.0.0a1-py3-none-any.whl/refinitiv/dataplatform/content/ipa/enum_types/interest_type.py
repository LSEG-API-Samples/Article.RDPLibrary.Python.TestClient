# coding: utf8

__all__ = ["InterestType"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class InterestType(Enum):
    """
    Flag that indicates whether the leg is fixed or float. Possible values are:
        - FIXED : the leg has a fixed coupon),
        - FLOAT : the leg has a floating rate index).
        - STEPPED
    """

    FIXED = "Fixed"
    FLOAT = "Float"
    STEPPED = "Stepped"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(InterestType, _INTEREST_TYPE_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_INTEREST_TYPE_VALUES_IN_LOWER_BY_INTEREST, some)


_INTEREST_TYPE_VALUES = (t.value for t in InterestType)
_INTEREST_TYPE_VALUES_IN_LOWER_BY_INTEREST = {name.lower(): item for name, item in list(InterestType.__members__.items())}

