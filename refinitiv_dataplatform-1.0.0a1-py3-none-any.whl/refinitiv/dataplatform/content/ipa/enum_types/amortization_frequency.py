# coding: utf8

__all__ = ["AmortizationFrequency"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class AmortizationFrequency(Enum):
    EVERY_COUPON = "EveryCoupon"
    EVERY_2ND_COUPON = "Every2ndCoupon"
    EVERY_3RD_COUPON = "Every3rdCoupon"
    EVERY_4TH_COUPON = "Every4thCoupon"
    EVERY_12TH_COUPON = "Every12thCoupon"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(AmortizationFrequency, AMORTIZATION_FREQUENCY_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_AMORTIZATION_FREQUENCY_VALUES_IN_LOWER_BY_AMORTIZATION_FREQUENCY, some)


AMORTIZATION_FREQUENCY_VALUES = (t.value for t in AmortizationFrequency)
_AMORTIZATION_FREQUENCY_VALUES_IN_LOWER_BY_AMORTIZATION_FREQUENCY = {
    name.lower(): item for name, item in list(AmortizationFrequency.__members__.items())}
