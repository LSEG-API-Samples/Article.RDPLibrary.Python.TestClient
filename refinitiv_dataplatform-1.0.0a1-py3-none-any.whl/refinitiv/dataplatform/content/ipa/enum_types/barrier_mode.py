# coding: utf8

__all__ = ["BarrierMode"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class BarrierMode(Enum):
    UNDEFINED = "Undefined"
    EUROPEAN = "European"
    AMERICAN = "American"
    FORWARD_START_WINDOW = "ForwardStartWindow"
    EARLY_END_WINDOW = "EarlyEndWindow"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(BarrierMode, BARRIER_MODE_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_BARRIER_MODE_VALUES_IN_LOWER_BY_BARRIER_MODE_VALUES, some)


BARRIER_MODE_VALUES = (t.value for t in BarrierMode)
_BARRIER_MODE_VALUES_IN_LOWER_BY_BARRIER_MODE_VALUES = {
    name.lower(): item for name, item in list(BarrierMode.__members__.items())}

