# coding: utf8

__all__ = ["ProjectedIndexCalculationMethod"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class ProjectedIndexCalculationMethod(Enum):
    """
    Flag used to define how projected index is computed.
    Available values are:
        - CONSTANT_INDEX : future index values are considered as constant and equal to projected index value.
        - FORWARD_INDEX : future index values are computed using a forward curve.
    """

    CONSTANT_INDEX = "ConstantIndex"
    FORWARD_INDEX = "ForwardIndex"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(ProjectedIndexCalculationMethod, PROJECTED_INDEX_CALCULATION_METHOD_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_PROJECTED_INDEX_CALCULATION_METHOD_VALUES_IN_PROJECTED_INDEX_CALCULATION_METHOD, some)


PROJECTED_INDEX_CALCULATION_METHOD_VALUES = (t.value for t in ProjectedIndexCalculationMethod)
_PROJECTED_INDEX_CALCULATION_METHOD_VALUES_IN_PROJECTED_INDEX_CALCULATION_METHOD = {
    name.lower(): item for name, item in list(ProjectedIndexCalculationMethod.__members__.items())}
