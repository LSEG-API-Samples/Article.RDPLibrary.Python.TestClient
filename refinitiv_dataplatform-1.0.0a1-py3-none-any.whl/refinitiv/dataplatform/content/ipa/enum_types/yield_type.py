# coding: utf8

__all__ = ["YieldType"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


class YieldType(Enum):
    """
    YieldType that specifies the rate structure.
        - NATIVE : no specific yield type is defined.
        - US_GOVT : US Govt Act/Act 6M YTA.
        - US_BILLS : US Bills Act/Act 6M YTA.
        - ISMA : ISMA 30/360 6M YTA.
        - EUROLAND : Euroland Equivalent Act/Act 6M YTA.
        - DISCOUNT_ACTUAL_360 : Money Market Act/360 6M YTA.
        - DISCOUNT_ACTUAL_365 : Money Market Act/365 6M YTA.
        - DISCOUNT_ACTUAL_ACTUAL : Money Market Act/Act 6M YTA.
        - BOND_ACTUAL_364 : Bond Market Act/364 6M YTA.
        - JAPANESE_SIMPLE : Japanese Simple JAP 6M YTA.
        - JAPANESE_COMPOUNDED : Japanese Compounded 30/360 6M YTA.
        - MOOSMUELLER : Moosmueller 30/360 6M YTA.
        - BRAESS_FANGMEYER : Braess-Frangmeyer 30/360 6M YTA.
        - WEEKEND : Week End 30/360 6M YTA
        - TURKISH_COMPOUNDED : Turkish Compounded 30/360 6M YTA.
    """

    NATIVE = "Native"
    US_GOVT = "UsGovt"
    US_BILLS = "UsTBills"
    ISMA = "Isma"
    EUROLAND = "Euroland"
    DISCOUNT_ACTUAL_360 = "Discount_Actual_360"
    DISCOUNT_ACTUAL_365 = "Discount_Actual_365"
    MONEY_MARKET_ACTUAL_360 = "MoneyMarket_Actual_360"
    MONEY_MARKET_ACTUAL_365 = "MoneyMarket_Actual_365"
    MONEY_MARKET_ACTUAL_ACTUAL = "MoneyMarket_Actual_Actual"
    BOND_ACTUAL_364 = "Bond_Actual_364"
    JAPANESE_SIMPLE = "Japanese_Simple"
    JAPANESE_COMPOUNDED = "Japanese_Compounded"
    MOOSMUELLER = "Moosmueller"
    BRAESS_FANGMEYER = "Braess_Fangmeyer"
    WEEKEND = "Weekend"
    TURKISH_COMPOUNDED = "TurkishCompounded"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(YieldType, _YIELD_TYPE_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_YIELD_TYPE_VALUES_IN_LOWER_BY_YIELD_TYPE, some)


_YIELD_TYPE_VALUES = (t.value for t in YieldType)
_YIELD_TYPE_VALUES_IN_LOWER_BY_YIELD_TYPE = {
    name.lower(): item for name, item in list(YieldType.__members__.items())}
