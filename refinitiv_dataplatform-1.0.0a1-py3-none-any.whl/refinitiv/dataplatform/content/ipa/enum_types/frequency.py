# coding: utf8

__all__ = ["Frequency"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class Frequency(Enum):
    ANNUAL = "Annual"
    SEMIANNUAL = "SemiAnnual"
    QUARTERLY = "Quarterly"
    MONTHLY = "Monthly"
    BIMONTHLY = "BiMonthly"
    EVERYDAY = "Everyday"
    EVERYDAY7DAYES = "Every7Days"
    EVERYDAY14DAYES = "Every14Days"
    EVERYDAY28DAYES = "Every28Days"
    EVERYDAY30DAYES = "Every30Days"
    EVERYDAY91DAYES = "Every91Days"
    EVERYDAY182DAYES = "Every182Days"
    EVERYDAY364DAYES = "Every364Days"
    EVERYDAY365DAYES = "Every365Days"
    EVERYDAY90DAYES = "Every90Days"
    EVERYDAY92DAYES = "Every92Days"
    EVERYDAY93DAYES = "Every93Days"
    EVERYDAY180DAYES = "Every180Days"
    EVERYDAY183DAYES = "Every183Days"
    EVERYDAY184DAYES = "Every184Days"
    EVERYDAY4MONTHS = "Every4Months"
    R2 = "R2"
    R4 = "R4"
    ZERO = "Zero"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(Frequency, INDEX_RESET_FREQUENCY_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_INDEX_RESET_FREQUENCY_VALUES_IN_LOWER_BY_INDEX_RESET_FREQUENCY, some)


INDEX_RESET_FREQUENCY_VALUES = (t.value for t in Frequency)
_INDEX_RESET_FREQUENCY_VALUES_IN_LOWER_BY_INDEX_RESET_FREQUENCY = {
    name.lower(): item for name, item in list(Frequency.__members__.items())}

