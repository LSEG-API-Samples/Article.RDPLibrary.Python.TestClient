# coding: utf8

__all__ = ["CalculationMethod"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class CalculationMethod(Enum):
    """
    The Day Count Basis method used to calculate a value.
    """

    DCB_30_360 = "Dcb_30_360"
    DCB_30_360_GERMAN = "Dcb_30_360_German"
    DCB_30_360_ISDA = "Dcb_30_360_ISDA"
    DCB_30_365_ISDA = "Dcb_30_365_ISDA"
    DCB_30_365_GERMAN = "Dcb_30_365_German"
    DCB_30_365_BRAZIL = "Dcb_30_365_Brazil"
    DCB_30_ACTUAL_GERMAN = "Dcb_30_Actual_German"
    DCB_30_ACTUAL = "Dcb_30_Actual"
    DCB_30_ACTUAL_ISDA = "Dcb_30_Actual_ISDA"
    DCB_30_ACTUAL_ISMA = "Dcb_30_Actual_ISMA"
    DCB_30E_360 = "Dcb_30E_360_ISMA"
    DCB_ACTUAL_360 = "Dcb_Actual_360"
    DCB_ACTUAL_364 = "Dcb_Actual_364"
    DCB_ACTUAL_365 = "Dcb_Actual_365"
    DCB_ACTUAL_ACTUAL = "Dcb_Actual_Actual"
    DCB_ACTUAL_ACTUAL_ISDA = "Dcb_Actual_Actual_ISDA"
    DCB_ACTUAL_ACTUAL_AFB = "Dcb_Actual_Actual_AFB"
    DCB_WORKING_DAYS_252 = "Dcb_WorkingDays_252"
    DCB_ACTUAL_365L = "Dcb_Actual_365L"
    DCB_ACTUAL_365P = "Dcb_Actual_365P"
    DCP_ACTUAL_LEAPDAY_365 = "Dcb_ActualLeapDay_365"
    DCP_ACTUAL_LEAPDAY_360 = "Dcb_ActualLeapDay_360"
    DCP_ACTUAL_36525 = "Dcb_Actual_36525"
    DCP_ACTUAL_365_CANADIAN_CONVENTION = "Dcb_Actual_365_CanadianConvention"
    DCB_CONSTANT = "Dcb_Constant"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(CalculationMethod, CALCULATION_METHOD_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_CALCULATION_METHOD_VALUES_IN_LOWER_BY_CALCULATION_METHOD, some)


CALCULATION_METHOD_VALUES = (t.value for t in CalculationMethod)
_CALCULATION_METHOD_VALUES_IN_LOWER_BY_CALCULATION_METHOD = {
    name.lower(): item for name, item in list(CalculationMethod.__members__.items())}
