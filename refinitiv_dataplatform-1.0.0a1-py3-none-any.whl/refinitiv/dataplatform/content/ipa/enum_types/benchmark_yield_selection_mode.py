# coding: utf8

__all__ = ["BenchmarkYieldSelectionMode"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class BenchmarkYieldSelectionMode(Enum):
    """
    The benchmark yield selection mode:
        - INTERPOLATE : do an interpolation on yield curve to compute the reference yield.
        - NEAREST : use the nearest point to find the reference yield.
    """

    INTERPOLATE = "Interpolate"
    NEAREST = "Nearest"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(Direction, DIRECTION_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_DIRECTION_VALUES_IN_LOWER_BY_DIRECTION, some)


BENCHMARK_YIELD_SELECTION_MODE_VALUES = (t.value for t in BenchmarkYieldSelectionMode)
_BENCHMARK_YIELD_SELECTION_MODE_VALUES_IN_BENCHMARK_YIELD_SELECTION_MODE = {
    name.lower(): item for name, item in list(BenchmarkYieldSelectionMode.__members__.items())}
