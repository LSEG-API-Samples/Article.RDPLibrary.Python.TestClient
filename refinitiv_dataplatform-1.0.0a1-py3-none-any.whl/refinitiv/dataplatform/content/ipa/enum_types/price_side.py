# coding: utf8

__all__ = ["PriceSide"]

from enum import Enum, unique
from.common_tools import _convert_to_str, _normalize


@unique
class PriceSide(Enum):
    """
    Quoted price side of the bond to use for pricing Analysis:
        - MID : Mid value,
        - BID : Bid value,
        - ASK : Ask value,
        - LAST : Last value
    """

    MID = "Mid"
    BID = "Bid"
    ASK = "Ask"
    LAST = "Last"

    @staticmethod
    def convert_to_str(some):
        return _convert_to_str(PriceSide, PRICESIDE_VALUES, some)

    @staticmethod
    def normalize(some):
        return _normalize(_PRICESIDE_VALUES_IN_LOWER_BY_PRICESIDE, some)


PRICESIDE_VALUES = (t.value for t in PriceSide)
_PRICESIDE_VALUES_IN_LOWER_BY_PRICESIDE = {
    name.lower(): item for name, item in list(PriceSide.__members__.items())}
