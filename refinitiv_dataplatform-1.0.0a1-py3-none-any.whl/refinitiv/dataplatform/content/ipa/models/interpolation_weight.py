# coding: utf8


__all__ = ["InterpolationWeight"]

from refinitiv.dataplatform.content.ipa.instrument import InstrumentPricingParams
from .day_weight import DayWeight


class InterpolationWeight(InstrumentPricingParams):

    def __init__(self, day_list, holidays, week_days, week_ends):
        super().__init__()
        self.day_list = day_list
        self.holidays = holidays
        self.week_days = week_days
        self.week_ends = week_ends

    @property
    def day_list(self):
        return self._get_object_parameter(DayWeight, "dayList")

    @day_list.setter
    def day_list(self, value):
        self._set_object_parameter(DayWeight, "dayList", value)

    @property
    def holidays(self):
        return self._get_parameter("holidays")

    @holidays.setter
    def holidays(self, value):
        self._set_parameter("holidays", value)

    @property
    def week_days(self):
        return self._get_parameter("weekDays")

    @week_days.setter
    def week_days(self, value):
        self._set_parameter("weekDays", value)

    @property
    def week_ends(self):
        return self._get_parameter("weekEnds")

    @week_ends.setter
    def week_ends(self, value):
        self._set_parameter("weekEnds", value)
