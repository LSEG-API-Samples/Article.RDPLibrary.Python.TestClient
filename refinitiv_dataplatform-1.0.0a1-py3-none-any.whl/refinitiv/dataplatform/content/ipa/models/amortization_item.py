# coding: utf8


__all__ = ["AmortizationItem"]

from refinitiv.dataplatform.content.ipa.instrument import InstrumentPricingParams
from refinitiv.dataplatform.content.ipa.enum_types import AmortizationFrequency


class AmortizationItem(InstrumentPricingParams):
    """
    General class to describe a section item of amortization schedule
    """
    def __init__(self,
                 amortization_frequency=None,
                 amortization_type=None,
                 remaining_notional=None,
                 start_date=None,
                 end_date=None,
                 first_amortization_date=None,
                 amount=None
                 ):
        super().__init__()
        self.amortization_frequency = amortization_frequency
        self.amortization_type = amortization_type
        self.remaining_notional = remaining_notional
        self.start_date = start_date
        self.end_date = end_date
        self.first_amortization_date = first_amortization_date
        self.amount = amount

    @property
    def remaining_notional(self):
        """
        :return: double
        """
        return self._get_parameter("RemainingNotional")

    @remaining_notional.setter
    def remaining_notional(self, value):
        self._set_parameter("RemainingNotional", value)

    @property
    def amortization_frequency(self):
        return self._get_enum_parameter(AmortizationFrequency, "AmortizationFrequency")

    @amortization_frequency.setter
    def amortization_frequency(self, value):
        self._set_enum_parameter(AmortizationFrequency, "AmortizationFrequency", value)

    @property
    def first_amortization_date(self):
        return self._get_parameter("firstAmortizationDate")

    @first_amortization_date.setter
    def first_amortization_date(self, value):
        self._set_parameter("firstAmortizationDate", value)

    @property
    def amount(self):
        return self._get_parameter.get("amount")

    @amount.setter
    def amount(self, value):
        self._set_parameter("amount", value)

    @property
    def amortization_type(self):
        return self._get_parameter("amortizationType")

    @amortization_type.setter
    def amortization_type(self, value):
        self._set_parameter("amortizationType", value)

    @property
    def start_date(self):
        """
        Start Date of an amortization section/window, or stepped rate
        :return: datetime
        """
        return self._set_parameter("startDate")

    @start_date.setter
    def start_date(self, value):
        self._set_parameter("startDate", value)

    @property
    def end_date(self):
        """
        End Date of an amortization section/window, or stepped rate
        :return: datetime
        """
        return self._get_parameter("endDate")

    @end_date.setter
    def end_date(self, value):
        self._set_parameter("endDate", value)
