# coding: utf8


__all__ = ["DayWeight"]

from refinitiv.dataplatform.content.ipa.instrument import InstrumentPricingParams


class DayWeight(InstrumentPricingParams):

    def __init__(self, date, weight):
        super().__init__()
        self.date = date
        self.weight = weight

    @property
    def date(self):
        return self._get_parameter("date")

    @date.setter
    def date(self, value):
        self._set_parameter("date", value)

    @property
    def weight(self):
        return self._get_parameter("weight")

    @weight.setter
    def weight(self, value):
        self._set_parameter("weight", value)
