# coding: utf8


__all__ = ["BidAskMid"]

from refinitiv.dataplatform.content.ipa.instrument import InstrumentPricingParams


class BidAskMid(InstrumentPricingParams):

    def __init__(self, bid, ask, mid):
        super().__init__()
        self.bid = bid
        self.ask = ask
        self.mid = mid

    @property
    def bid(self):
        return self._get_parameter("bid")

    @bid.setter
    def bid(self, value):
        self._set_parameter("bid", value)

    @property
    def ask(self):
        return self._get_parameter("ask")

    @ask.setter
    def ask(self, value):
        self._set_parameter("ask", value)

    @property
    def mid(self):
        return self._get_parameter("mid")

    @mid.setter
    def mid(self, value):
        self._set_parameter("mid", value)
