__all__ = [
    "get_news_headlines", "get_news_headlines_async",
    "get_headlines", "get_headlines_async",
    "get_news_story", "get_news_story_async",
    "get_story", "get_story_async"
]

from refinitiv.dataplatform.content.news.sort_order import SortOrder
from .news_headlines import NewsHeadlines
from .news_story import NewsStory


def _get_default_session():
    from refinitiv.dataplatform.legacy import get_default_session
    return get_default_session()


# <editor-fold desc="========================================= Headlines =========================================">

def get_headlines(
        query="Topic:TOPALL and Language:LEN",
        count=10,
        date_from=None,
        date_to=None,
        sort_order=SortOrder.new_to_old,
        on_response=None,
        on_page_response=None,
        closure=None,
        session=None
):
    session = session or _get_default_session()
    news_headlines = NewsHeadlines(session=session, on_response=on_response)
    response = news_headlines.get_headlines(
        query,
        count=count,
        date_to=date_to,
        date_from=date_from,
        sort_order=sort_order,
        on_page_response=on_page_response,
        closure=closure
    )
    return response


def get_news_headlines(
        query="Topic:TOPALL and Language:LEN",
        count=10,
        date_from=None,
        date_to=None,
        sort_order=SortOrder.new_to_old,
        on_response=None,
        on_page_response=None,
):
    response = get_headlines(
        query=query,
        count=count,
        date_from=date_from,
        date_to=date_to,
        sort_order=sort_order,
        on_response=on_response,
        on_page_response=on_page_response,
    )
    df = response.data.df
    return df


async def get_headlines_async(
        query="Topic:TOPALL and Language:LEN",
        count=10,
        date_from=None,
        date_to=None,
        sort_order=SortOrder.new_to_old,
        on_response=None,
        on_page_response=None,
        closure=None,
        session=None
):
    session = session or _get_default_session()
    news_headlines = NewsHeadlines(session=session, on_response=on_response)
    response = await news_headlines.get_headlines_async(
        query,
        count=count,
        date_to=date_to,
        date_from=date_from,
        sort_order=sort_order,
        on_page_response=on_page_response,
        closure=closure
    )
    return response


async def get_news_headlines_async(
        query="Topic:TOPALL and Language:LEN",
        count=10,
        date_from=None,
        date_to=None,
        sort_order=SortOrder.new_to_old,
        on_response=None,
        on_page_response=None,
        closure=None
):
    response = await get_headlines_async(
        query=query,
        count=count,
        date_from=date_from,
        date_to=date_to,
        sort_order=sort_order,
        on_response=on_response,
        on_page_response=on_page_response,
        closure=closure
    )
    df = response.data.df
    return df


# </editor-fold>
# <editor-fold desc="========================================= Story =========================================">

def get_story(
        story_id,
        on_response=None,
        closure=None,
        session=None
):
    session = session or _get_default_session()
    news_story = NewsStory(session=session, on_response=on_response)
    response = news_story.get_story(story_id, closure)
    return response


def get_news_story(story_id):
    response = get_story(story_id)
    text = response.data.text
    return text


async def get_story_async(
        story_id,
        on_response=None,
        closure=None,
        session=None
):
    session = session or _get_default_session()
    news_story = NewsStory(session=session, on_response=on_response)
    response = await news_story.get_story_async(story_id, closure)
    return response


async def get_news_story_async(story_id):
    response = await get_story_async(story_id)
    text = response.data.text
    return text

# </editor-fold>
