import json
import os
import re
from json import JSONDecodeError
from json.decoder import WHITESPACE

CONFIG_FILES = 'rdp.json', '.rdp.json', 'rdp.default.json'


def _get_config_file(rootdir=None):
    if rootdir is None:
        return DEFAULT_CONFIG_FILE

    for path in CONFIG_FILES:
        path = os.path.join(rootdir, path)

        if os.path.isfile(path) and os.access(path, os.R_OK):
            return path


DEFAULT_CONFIG_FILE = _get_config_file(os.path.dirname(__file__))
USER_CONFIG_FILE = _get_config_file(os.path.expanduser('~'))
PROJECT_CONFIG_FILE = _get_config_file(os.getcwd())


class _JSONDecoder(json.JSONDecoder):
    pattern = re.compile(r'.*?\${(\w+)}.*?')

    def decode(self, s, _w=WHITESPACE.match):
        match = _JSONDecoder.pattern.findall(s)
        if match:
            for g in match:
                s = s.replace(f'${{{g}}}', os.environ.get(g, g))
            s = s.replace('\\', '\\\\')
        return super().decode(s, _w)


def _merge_configs_files(paths, config=None):
    config = config or {}
    for p in paths:
        if not p:
            continue

        if os.path.isfile(p) and os.access(p, os.R_OK):
            with open(p, 'r') as f:
                try:
                    data = json.load(f, cls=_JSONDecoder)
                except JSONDecodeError as e:
                    f.seek(0)
                    raise Exception(f'{e.args} in file: {f.name}: {f.read()}')
            config.update(data)

        else:
            raise Exception(f'Can not read config file: {p.name}')

    return config


def get_config(file_path=None, rootdir=None):
    paths = [DEFAULT_CONFIG_FILE, USER_CONFIG_FILE, PROJECT_CONFIG_FILE]

    if not file_path:
        path = _get_config_file(rootdir)

        if path:
            paths.append(path)

    else:
        paths.append(file_path)

    config = _merge_configs_files(paths)
    return config
